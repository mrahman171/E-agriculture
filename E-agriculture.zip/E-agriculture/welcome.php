 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<!DOCTYPE html>
<html>
  
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}

.topnav-right {
  float: right;
}
</style>
</head>

<body>

<div class="topnav">
  
   
  <a href="contact.php">Contact</a>
  <div class="topnav-right">
   
    <a href="logout.php">LOGOUT</a>
  </div>
</div>

<div style="padding-left:16px">
  <h2></h2>
   
</div>

</body>

</html>

<body>
    <div class="page-header">
        <h1><b></b>Welcome Agriculture Assist</h1>
    </div>
    <p>
         
        
        <a href="index.php" class="btn btn-danger">Submit Your Problem</a>
        <a href="productup.php" class="btn btn-danger">Submit Your Products</a>
        <a href="index3.php" class="btn btn-danger">See Your Solutions Here</a>
         
    </p>

</body>
<style>
body, html {
  height: 83%;
  margin: 0;
}
.bg {
  background-image: url("3rd.jpg");
  height: 100%; 
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
</head>
<body>
<div class="bg"></div>
</html>