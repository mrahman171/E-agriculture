<html>
<head>
    
<title>insert from data in mysql database using php</title>
    <style type="text/css">
        table {front font-size: 30px; margin-left: 25%;margin-top:-24%} 
        input,textarea{front-size :30px;}
    </style>
</head>
<body>

<form action="verifylogin.php"  method="post">
			Username: <input type="text" placeholder="User Name Here" id="uname" name="uname">
			<br/>
			Password: <input type="password" id="pass" name="pass">
			<br/>
			<input type="submit" value="Log In">
    
              <input type="submit" value="creat account?">
		</form>

<br/><br/><br/><br/>
    <from action="" method ="post">

    <table>
        <tr>
            <th></th>
            <th><h2>User Registration Form</h2></th>
        </tr>
          <tr>
            <td> First Name:</td>
            <td><textarea input type ="text" name ="First Name"></textarea></td>
        </tr>
         <tr>
            <td> Last Name:</td>
            <td><textarea input type ="text" name ="last Name"></textarea></td>
        </tr>
        <tr>
            <td> User Name:</td>
            <td><textarea input type ="text" name ="Username"></textarea></td>
        </tr>
        <tr>
            <td> Password:</td>
            <td><textarea input type ="password" name ="password"></textarea></td>
        </tr>
        <tr>
            <td>Contact Number:</td>
            <td><textarea input type ="text" name ="Mobile_number"></textarea></td>
        </tr>
        
        <tr>
            <td> Address:</td>
            <td><textarea rows="3" cols="25" name="address"></textarea></td>
        </tr>
        
<tr>

      <button type="button" style="background-color:white;
margin-left:35%;margin-right:auto;display:block;margin-top:15%;margin-bottom:0%">
   Register
</button>
</tr>
        
                
        
    </table> </from>

    
 </body>
</html>