<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.container {
  position: relative;
  font-family: Arial;
}

.text-block {
  position: absolute;
  bottom: 20px;
  right: 20px;
  background-color: black;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}
</style>
</head>
<body>
  <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-green: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>

<div class="topnav">
  <a class="active" href="home.php">Home</a>
  <a href="contact.php">Contact</a>
   
</div>

 

</body>
</html>
 
<div class="container">
  <img src="222.jpg" alt="Nature" style="width:100%;">
  <div class="text-block">
    <h4>Nature</h4>
    <p>E_agriculture.com is dedicated to provide service to farmers across the country.
      Here farmers can register and post their products for sale and also they can upload images of any problems they faced regarding their crops.Which a group of experts available will be providing solutions through Voice-Messages.</p>
      <p>We are always availabe in the aid of any Farmer trying to sell his/her crops.</p>
  </div>
</div>
    <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.btn {
  border: none;
  background-color: inherit;
  padding: 14px 28px;
  font-size: 16px;
  cursor: pointer;
  display: inline-block;
}

.btn:hover {background: #eee;}

.success {color: green;}
.info {color: dodgerblue;}
.warning {color: orange;}
.danger {color: red;}
.default {color: black;}
</style>
</head>
<body>
<button class="btn success">Event</button>
<button class="btn info">Info</button>
</body>
</html>


</body>
</html> 
